<template>
  <div class="container-fluid">

    <div class="container menu">
      <div class="container pt-5">
        <img src="../assets/logo.png" style="height:40px"  alt="" >
      </div>
      <!----------------------OUR Menu------------------- -->
      <div class="container pb-5" id="menu">
        <h4 class="text-center heading" style="font-weight: bold; padding-top:70px">Quant souhaite-vous acheter</h4>
        <p class="text-center heading" style="font-weight: bold;">Choisissez un jour de ramessage</p>

        <div class="row mt-5">


          <div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">
            <div class="card cartt">
              <div class="card-body text-center">
                <h5 class="card-title top"><img src="../assets/menu1.png" class=" img-fluid" alt=""></h5>
                <h5 class="card-subtitle text-left p-3" style="font-weight:bold">BiBimBap</h5>
                <p class="card-text text-left">On the Insert tab, the galleries include itemsOn the Insert tab, the
                  galleries include itemsOn the Insert tab, the galleries include itemsOn the Insert tab, include items
                </p>
                <p class="text-right">
                  <button type="button" class="btn btn-primary" data-toggle="modal"
                    data-target="#exampleModalLong">9.00$</button>
                </p>

              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">
            <div class="card cartt">
              <div class="card-body text-center">
                <h5 class="card-title top"><img src="../assets/menu1.png" class=" img-fluid" alt=""></h5>
                <h5 class="card-subtitle text-left p-3" style="font-weight:bold">BiBimBap</h5>
                <p class="card-text text-left">On the Insert tab, the galleries include itemsOn the Insert tab, the
                  galleries include itemsOn the Insert tab, the galleries include itemsOn the Insert tab, include items
                </p>
                <p class="text-right">
                  <button type="button" class="btn btn-primary" data-toggle="modal"
                    data-target="#exampleModalLong">9.00$</button>
                </p>

              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">
            <div class="card cartt">
              <div class="card-body text-center card-img-top">
                <h5 class="card-title top">
                  <img src="../assets/menu1.png" class=" img-fluid " alt="">
                </h5>
                <h5 class="card-subtitle text-left p-3" style="font-weight:bold">BiBimBap</h5>
                <p class="card-text text-left">On the Insert tab, the galleries include itemsOn the Insert tab, the
                  galleries include itemsOn the Insert tab, the galleries include itemsOn the Insert tab, include items
                </p>
                <p class="text-right">
                  <button type="button" class="btn btn-primary" data-toggle="modal"
                    data-target="#exampleModalLong">9.00$</button>
                </p>

              </div>
            </div>
          </div>
        </div>

        <div class="row mt-5">


          <div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">
            <div class="card cartt">
              <div class="card-body text-center">
                <h5 class="card-title top"><img src="../assets/menu1.png" class=" img-fluid" alt=""></h5>
                <h5 class="card-subtitle text-left p-3" style="font-weight:bold">BiBimBap</h5>
                <p class="card-text text-left">On the Insert tab, the galleries include itemsOn the Insert tab, the
                  galleries include itemsOn the Insert tab, the galleries include itemsOn the Insert tab, include items
                </p>
                <p class="text-right">
                  <button type="button" class="btn btn-primary" data-toggle="modal"
                    data-target="#exampleModalLong">9.00$</button>
                </p>

              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">
            <div class="card cartt">
              <div class="card-body text-center">
                <h5 class="card-title top"><img src="../assets/menu1.png" class=" img-fluid" alt=""></h5>
                <h5 class="card-subtitle text-left p-3" style="font-weight:bold">BiBimBap</h5>
                <p class="card-text text-left">On the Insert tab, the galleries include itemsOn the Insert tab, the
                  galleries include itemsOn the Insert tab, the galleries include itemsOn the Insert tab, include items
                </p>
                <p class="text-right">
                  <button type="button" class="btn btn-primary" data-toggle="modal"
                    data-target="#exampleModalLong">9.00$</button>
                </p>

              </div>
            </div>
          </div>

          <div class="col-md-4 col-sm-12 col-xs-12 col-lg-4">
            <div class="card cartt">
              <div class="card-body text-center card-img-top">
                <h5 class="card-title top">
                  <img src="../assets/menu1.png" class=" img-fluid " alt="">
                </h5>
                <h5 class="card-subtitle text-left p-3" style="font-weight:bold">BiBimBap</h5>
                <p class="card-text text-left">On the Insert tab, the galleries include itemsOn the Insert tab, the
                  galleries include itemsOn the Insert tab, the galleries include itemsOn the Insert tab, include items
                </p>
                <p class="text-right">
                  <button type="button" class="btn btn-primary" data-toggle="modal"
                    data-target="#exampleModalLong">9.00$</button>
                </p>

              </div>
            </div>
          </div>
        </div>  



        <!-- Button trigger modal -->

        <!-- Modal -->
        <div class="container d-flex justify-content-center">
          <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <h5 class="modal-title p-2" id="exampleModalLongTitle">Choose Options   <button type="button" class="close"
                    data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button></h5>
               

                <h5 class="text-center">
                  <img src="../assets/menu1.png" class=" img-fluid " alt="">
                </h5>
                <div class="modal-header">


                  <div class="row">
                    <div class="col-md-12">
                      <h5 class="card-subtitle text-left p-3" style="font-weight:bold">BiBimBap</h5>
                      <p class="card-text text-left">On the Insert tab, the galleries include itemsOn the Insert tab,
                        the
                        galleries include itemsOn the Insert tab, the galleries include itemsOn the Insert tab, include
                        items
                      </p>
                    </div>
                    </div>
                    
                </div>
                <div class="modal-body">
               <p class="p-1 quantity" style="color:black">Select Quantity</p>
                  <ul class="ul">
                    <li class="li ">
                     <button class="shadow-lg btn modal-btn p-2"><i class="fa-solid fa-minus" style="color: #5AB9AE;"></i></button>
                    </li>
                    <li class="li">
                      <h4 style="width:50px;text-align:center;border-radius:8px;padding:5px;border:  1px solid #5AB9AE;">0</h4>
                    </li>

                    <li class="li">
                      <button class="shadow-lg btn modal-btn p-2"><i class="fa-solid fa-plus" style="color: #5AB9AE;"></i></button>
                    </li>
                  </ul>
                  <p class="p-4 form">
                  <select class="form-control p-4 shadow-lg" style="border-radius: 6px;" name="" id="" >
                    <option class="form-control" value="">Options</option>
                    <option value="">Options</option>
                    <option value="">Options</option>
                    <option value="">Options</option>
                  </select>

                  <textarea placeholder="Add delivery Instructions" style="border:none; border: 1px solid #5AB9AE;border-radius: 8px;" name="" class="form-control mt-3" id="" cols="30" rows="4"></textarea>
                  </p>
                  <h3 class="text-right">
                  <button style="background-color: #524582;;" type="button" class="btn btn-primary">Add to Cart</button>

                  </h3>



                </div>
                
              </div>
            </div>
          </div>


        </div>

           <ul class="nav-item">
        <li ><router-link to="menu1" class="nav-link left"><i class="fa-solid fa-arrow-up" style="color:#5AB9AE" ></i></router-link></li>
        <li><router-link to="menu3"  class="nav-link right"><i class="fa-solid fa-arrow-down" style="color:white"></i></router-link></li>
      </ul>
      </div>
    </div>
  </div>




</template>

<script>
export default {
  name: 'menu2',
  props: {
    msg: String
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.container-fluid {
background-color: #F7F7F7;
}

.ul .li {
  display: inline-block;
  padding:10px;
}
.quantity
{
      color: black;
    margin-left: 18px;
    font-size: 20px;
}
.form
{
   margin-top: -24px;
}
.ul
{
    margin-left: -26px;
    margin-top: -14px;
}
.modal-header
{
    padding-left: 32px;
    margin-top: -44px;
}
.card-subtitle
{
    font-weight: bold;
    margin-left: -14px;
}

.ul .li button{
  width:60px;
}

.nav-item li {
  display: inline-block;
  position: relative;
  left: 99%;
  top: -47px
}

.nav-item li .right {
  background-color: #5AB9AE;
  border-radius: 8px;
}

@media only screen and (max-width: 1300px) and (min-width: 600px) {
  .nav-item li {
    display: inline-block;
    position: relative;
    left: 50%;
    top: 40px
  }

  .nav-item li .right {
    background-color: #5AB9AE;
    border-radius: 8px;
  }

}

#id {
  margin-bottom: 300px;

}

.top {
  margin-top: -88px;
}
.modal-btn
{
  background-color: #fff!important;
  color: #5AB9AE;
}

.btn {
  background-color: #524582;
  border: none;
  color: white
}

.heading {
  color: #524582;
}

.col-md-4 {
  margin-top: 38px;
}

.col-sm-4 {
  margin-top: 60px;
}
.cartt
{
  width: 90%;
  border-radius: 16px;
}

</style>
