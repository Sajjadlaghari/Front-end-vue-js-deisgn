<template>
	<div class="container-fluid">
		<h1 class="fw-bold p-3 text-center" style="background-color:lightgray">ABOUT US</h1>
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-5">
				<img src="https://media.istockphoto.com/photos/about-us-word-on-a-red-wooden-block-picture-id1283119095?b=1&k=20&m=1283119095&s=170667a&w=0&h=n4qJJJJX45J557wORBTcLBT7KleWOeUIuig-OaCVOck=" class="shadow p-3">
			</div>

			<div class="col-md-5">		

				<p class="shadow p-3">
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				</p>


			</div>
		</div>
	</div>
</template>


<script >
	export default {
		name:'About',
	}
</script>


<style>

</style>