<template>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<img src="https://cdn.wallpapersafari.com/87/60/41gkr8.jpg" style="height:258px" class="img-fluid mt-2">
			</div>
			<div class="col-md-4">
				<img src="https://swall.teahub.io/photos/small/14-146189_desktop-on-download-data-src-full-12539-desktop.jpg" class="img-fluid mt-2" style="height:258px">
			</div>
			<div class="col-md-4">
				<img src="https://c4.wallpaperflare.com/wallpaper/383/883/768/technology-4k-desktop-background-wallpaper-preview.jpg" class="img-fluid mt-2" style="height:258px">
			</div>
		</div>

		<div class="row">
			<div class="col-md-4">
				<img src="https://www.designyourway.net/drb/wp-content/uploads/2015/05/Beach-Wallpaper-Desktop-Background-57-1600x1200.jpg" style="height:258px; width:500px" class="img-fluid mt-2">
			</div>
			<div class="col-md-4">
				<img src="https://wallpapercave.com/wp/wp2841679.jpg" class="img-fluid mt-2" style="height:258px">
			</div>
				<div class="col-md-4">
					<img src="https://i.pinimg.com/736x/15/f6/a3/15f6a3aac562ee0fadbbad3d4cdf47bc.jpg" class="img-fluid mt-2" style="height:258px">
				</div>
		</div>
	</div>
</template>


<script >
	export default {
		name:'Gallery',

		data()
		{
			return 
			{

			}
		},

		mounted()
		{
			
		}
	}
</script>


<style>

</style>